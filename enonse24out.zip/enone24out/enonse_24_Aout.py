class BankAccount:
    def __init__(self, account_number, account_holder, initial_balance):
        self.account_number = account_number
        self.account_holder = account_holder
        if initial_balance < 500.0:
            initial_balance = 500.0
        self.balance = initial_balance
    
    def deposit(self, amount):
        if amount > 0:
            self.balance += amount
    
    def withdraw(self, amount):
        if 0 < amount <= self.balance:
            self.balance -= amount
    
    def get_balance(self):
        return self.balance
    
    def __str__(self):  # Ou dwe itilize "__str__" ankò, pa "_str_"
        return f"Account Number: {self.account_number}\nAccount Holder: {self.account_holder}\nBalance: {self.balance:.2f} HTG"

# Kreye yon kont
account1 = BankAccount("00340203", "Lub Lorry", 10000.00)

# Depo
account1.deposit(500.00)

# Retrè
account1.withdraw(200.00)

# Verifye balans
balance = account1.get_balance()

# Afiche enfòmasyon sou kont lan
print(account1)